#!/usr/bin/python3
"""
##############################
## DEV_INFO:
######  Developed by:
##  Norah Brown - Natural Resources Canada, Siyu Li - University of Waterloo, Jean-François Bourgon - Natural Resources Canada
##  Crown Copyright as described in section 12 of Copyright Act (R.S.C., 1985, c. C-42)
##  © Her Majesty the Queen in Right of Canada, as represented by the Minister of Natural Resources Canada, 2019
## FILE_NAME: extract.py
##  Python 3.8 (v64b)
##  version 0.0 - 2021/03 nb/sl: initial development 
##  version 0.1 - 2021/03 nb: args assigned as vars inside script, Franklin api query HTTP GET method with parameters
##  version 0.2 - 2021/04 nb: masking needs to be employed to extract regions from image and get the proper the transform affine.
##                            replacing all window based reading of data with a mask for clipping
##                            for recasting and merging use recast_merge.py after this script
##                            for plots and histogram use plot_cog.py
##                            for 3d plot use plot3d_cog.py
##  version 0.4 - 2021/04 nb: combining recasting and merging functionalities
##                            adding argument to point to the geojson file and the study area field name,
##                            removed long lat as vars, study area needs to be defined in geojson file
##                            logging results to extract_main.log
##                            logging errors to extract_error.log
##  version 0.5 - 2021/04 nb: adding argument for goal cell size in m, and resampling method
##  version 0.6 - 2021/05 nb: adding in bbox argument, def geojson study area definition, adding wcs geotif extracts
##############################
## DESCRIPTION:
##  Selects a subset of cog based on geojson boundary file as a mask, writes it to local file
##      for recasting and merging use recast_merge.py after this script
##      for plots and histogram use plot_cog.py
##      for 3d plot use plot3d_cog.py
## USAGE:
##    # using geojson file to define study area
##    python extract.py -f "/space/partner/nrcan/geobase/work/transfer/work/datacube/DEV_UC/floodinput_studyareas.json" -field StudyArea -id ON -coll cdem -assettype dem -goaldtype 16 -goalcsize 16 -resample nearest -outpath /space/partner/nrcan/geobase/work/transfer/work/datacube/DEV_UC/extract/
##    python extract.py -f "C:\\users\\nbrown\\Documents\\DataCube\\HPC\\usecase\\extract\\input_studyareas.json" -field StudyArea -id ON -coll cdem -assettype dem -goaldtype 16 -goalcsize 16
##    # using bbox to define study area  
##    python extract.py -id ON -coll cdem -assettype dem -goaldtype 32 -goalprecision 4 -goalcsize 16  -resample nearest -bbox=-269985.0,90015.0,-265875.0,95895.0 -crs='EPSG:3979' -outpath /space/partner/nrcan/geobase/work/transfer/work/datacube/DEV_UC/extract/
##    python extract.py -id ON -coll cdem -assettype dem -goaldtype 32 -goalprecision 4 -goalcsize 16  -resample nearest -bbox=-269985.0,90015.0,-265875.0,95895.0 -crs='EPSG:3979' -outpath '/.' (optional argument -keeptemp True)
## REFERENCES:
## https://rasterio.readthedocs.io/en/latest/topics/windowed-rw.html
## https://numpy.org/doc/stable/reference/routines.statistics.html
## https://gdal.org/drivers/raster/gtiff.html#georeferencing
## https://rasterio.readthedocs.io/en/latest/topics/plotting.html
## https://matplotlib.org/stable/gallery/subplots_axes_and_figures/subplots_demo.html
## https://matplotlib.org/mpl_toolkits/mplot3d/tutorial.html
## https://rasterio.readthedocs.io/en/latest/api/rasterio.merge.html
## https://automating-gis-processes.github.io/CSC18/lessons/L6/raster-mosaic.html
## https://automating-gis-processes.github.io/CSC18/lessons/L6/clipping-raster.html
## https://numpy.org/doc/stable/reference/routines.statistics.html
## https://numpy.org/doc/stable/user/basics.types.html
## https://numpy.org/doc/stable/reference/generated/numpy.ndarray.astype.html
## https://het.as.utexas.edu/HET/Software/Numpy/reference/generated/numpy.ndarray.astype.html
## https://numpy.org/doc/stable/reference/generated/numpy.round_.html
## https://www.geeksforgeeks.org/python-exit-commands-quit-exit-sys-exit-and-os-_exit/
## https://rasterio.readthedocs.io/en/latest/api/rasterio.crs.html
## https://rasterio.readthedocs.io/en/latest/api/rasterio.enums.html#rasterio.enums.Resampling
## EXAMPLE COG:
## url="http://datacube-prod-data-public.s3.ca-central-1.amazonaws.com/store/dem/cdsm/cdsm-13-dem.tif"
## url="http://datacube-prod-data-public.s3.ca-central-1.amazonaws.com/store/dem/cdem/cdem-22-dem.tif"
##########
## EXAMPLE using extract.py as a module
## import extract as e
## #get dict bbox definition using default tbox
## g = e.getDictFromPoly((e.getPolyFromTbox()))
## e.getExtractFromWcs('cdem','dem','./','test2',g,'EPSG:3979',30,'http','dtm','dsm','stage','elevation','./main.log','./error.log')
## e.getExtractFromStac('cdem','dem','./','test2',g,'EPSG:3979','./main.log','./error.log')
##  TESTING HRDSM when no HRDEM available
## lid1 = 'dtm'
## lid2 = 'dsm'
## tbox='-110,85,-109.5,90'
## tbox='-124,60,-110,90'
## crs='EPSG:4326'
## level='stage'
## srv_id='elevation'
## g=e.getDictFromPoly((e.getPolyFromTbox(tbox)))
## infoDtm = e.getExtractFromWcs('cdem','dem','./','wcs_dtm_test',g,crs,30,'https',lid1,lid2,'stage','elevation','hrdsm_wcs_main.log','hrdsm_wcs_error.log')
## infoDsm = e.getExtractFromWcs('cdem','dem','./','wcs_dsm_test',g,crs,30,'https',lid1,lid2,'stage','elevation','hrdsm_wcs_main.log','hrdsm_wcs_error.log')
########## 
##   TESTING comparing selection bbox to wcs lids and creating bounding box .json files
## f_dtm = e.makeWcsBboxFile(lid='dtm',crs='EPSG:3979')
## f_dsm = e.makeWcsBboxFile(lid='dsm',crs='EPSG:3979')
## inter,diff = e.getGeoJsonBboxDifferences(f_dtm,f_dsm)
## e.makeVectorFile(inter,'EPSG:3979','./','dtm_dsm_intersection.json')
## e.makeVectorFile(diff,'EPSG:3979','./','dtm_dsm_difference.json')
##############################
##  TODO:
## add this study area -bbox=-269985.0,90015.0,-180015.0,179985.0 
##  delete the sub areas sample tifs <study_area>_sample_<origninal_file_name>
##      code is commented out directly aboce last exception block of main
##      starting with "print("cleaning up, deleting the sample files")"
##  do more sophisticated data recast, currently assumes downgrade so rounds
##  think about whether to recheck again after recasting
##      for unique dtypes on else of def mergeData (commented in else)
##  test if not metres, crs linear units can be other feet (getResolution)
##  Geotrellis server WCS passes back geotiff as COG, other WCS wont so should make sure to do internal tiling on WCS returns
##  Translate collection name and type of asset to WCS values for use in getWCS
##  modify so that main_log and error_log, and internal_log values from defs are written directly to log files
##  !!!fix the crs passing there is a need for 4326 in the stac intersect but is not clearly passed
##  !!!  figure out where best place for the transformation to take place IE right before intersect is done
##  !!!figure out better way to identify files that need to be merged currently '_sample' text but not var
##  !!! need to work on WCS nodata value current fix in recast is a temp patch that doesnt work for float nan from WCS
##  !!! For Norther Canada, if HRDEM does not return full extent of data, get HRDSM data.
##  !!! need to verify passing of crs and reprojections, little buggy on wcs extracts further investigation required
##  !!! properly handle outpath existance, creation, and passing of value and attaching to file name in all defs including geojson creation
######################
"""
import argparse
from datetime import datetime
import geopandas as gpd
import glob
import json
import numpy
import os
import rasterio

from rasterio.warp import transform_geom
from rasterio.windows import from_bounds, bounds, transform
from rasterio.mask import mask
from rasterio import windows, merge
import requests
from shapely.geometry import box, mapping, shape
import shapely
import sys
import xml.etree.ElementTree as et
import pathlib


def main(argv):
    main_log=[]
    recast_log=[]
    merge_log=[]
    error_log=[]
    internal_log=[]
    
    status_str="start {}".format(datetime.now())
    #print(status_str)
    main_log.append(status_str)

    ## Argument handeling
    parser = argparse.ArgumentParser(description='Extract and merge from cogs per study area, based on geojson study area boundary file')
    parser.add_argument('-f', required=False,
                       help='full path to file to be resampled or reprojected')
    parser.add_argument('-field', required=False,
                        help='geojson field that holds study area definition / id')
    parser.add_argument('-bbox', required=False,
                        help='bounding box coordinates')
    parser.add_argument('-crs', required=False,
                        help='bounding box crs (EPSG:3979)')
    parser.add_argument('-id',
                        help='study area id')
    parser.add_argument('-coll',
                        help='collection name (cdem, cdsm, etc.')
    parser.add_argument('-assettype',
                        help='type of asset (dem, hillshade, etc.')
    parser.add_argument('-goaldtype',
                        help='the goal datatype in bits (8,16,32)')
    parser.add_argument('-goalprecision', default=2,
                        help='the number of decimals places')
    parser.add_argument('-goalcsize',
                        help='the goal cell size in meters (30)')
    parser.add_argument('-resample',
                        help='the resampling method(nearest default)')
    parser.add_argument('-outpath',
                        help='path to output')
    parser.add_argument('-level', required=False, default='stage',
                        help='OGC service production level')
    parser.add_argument('-keeptemp', required=False, default=False,
                        help='keep temp tifs (default False)')
    
    #instantiate vars
    args=parser.parse_args(argv)        
    extract_id=args.id
    collection=args.coll
    asset_type=args.assettype
    cwd=checkOutpath(args.outpath)
    f_main=os.path.join(cwd,"extract_main.log")
    f_error=os.path.join(cwd,"extract_error.log")
    goal_dtype=int(args.goaldtype)
    goal_precision=int(args.goalprecision)
    goal_csize=int(args.goalcsize) # needs to be converted from metres to units of crs
    resample=getResampleEnum(args.resample)
    #suffix="study-area.tif"
    suffix = ".tif"
    if args.keeptemp == 'False':
        keeptemp = False
    else:
        keeptemp = True
    main_log.append("keeptemp assigned: {}, datatype {}".format(keeptemp,type(keeptemp)))
    level = args.level
    #level='stage'
    #level='prod'
    lid1 = 'dtm'
    lid2 = 'dsm'
    
    #print(keeptemp)
    #print(cwd)
    
    
    # handle if geojson study area is used
    if args.f:
        if not args.field:
            sys.exit("the study area geojson file must supply a field with study area name")
        else:
            geojson_file=args.f
            field=args.field
            # if geojson parameter used then get study area id and 4326 geometry from geojson
            study_area,g,crs = useStudyAreaGeojson(geojson_file,field,extract_id)
            #print("useStudyAreaGeojson study_area: {}".format(study_area))
            #print("useStudyAreaGeojson g: {}".format(g))
    # handle if bbox argument is used
    elif args.bbox:
        if not args.crs:
            sys.exit("the crs must be supplied with the bbox")
        else:
            tbox=args.bbox
            crs=args.crs
            #print('tbox vals as args {}'.format(tbox))
            # if bbbox parameter used the get vars
            study_area = extract_id
            #get dict from shapley polygon
            g = getDictFromPoly((getPolyFromTbox(tbox)))
            
    # handle if no file or bbox
    else:
        sys.exit("either a study area geojson file and field name or a bbox and crs must be passed in as arguments see --help")

    # delete any exisiting sample area tifs
    internal_log.append(deleteSampleAreaTifs(cwd,study_area,f_main,f_error))

    ## creating wcs first has the files show up first in the glob which puts them first in list of files to be merged
    ## with merge default 'reverse painters' wcs files will be the boss layer

    # make local extract files from WCS
    protocol='https'
    wcs_files,wcs_log = getExtractFromWcs(collection,asset_type,cwd,
                                          study_area,g,crs,goal_csize,
                                          protocol,lid1,lid2,level,
                                          f_main,f_error)
    internal_log.append(wcs_log)
    internal_log.append("created cog(s) from WCS {}".format(wcs_files))
    internal_log.append(appendListToFile(internal_log,f_main))
    main_log.append(wcs_log)
    main_log.append("completed extracting from WCS for study areas %s"%(str(datetime.now())))
    
    #make local extract files from stac
    stac_files,stac_log = getExtractFromStac(collection,asset_type,cwd,study_area,g,crs,f_main,f_error)
    internal_log.append(stac_log)
    internal_log.append("created cog(s) from WCS {}".format(stac_files))
    main_log.append("completed extracting from STAC/COG for study areas %s"%(str(datetime.now())))

    
    # for each province, merge the sample area clips from each tile
    main_log.append("merging extracts per study area")
    try:
        sub_areas=sorted(glob.glob("%s/%s_sample-*.tif"%(cwd,study_area)),reverse=True)
        num_sa=len(sub_areas)
        if num_sa==0:
            main_log.append("no study areas available, exiting")
            sys.exit("No study areas")
        datasets=[]
        if num_sa==1:
        # if there is only a single tile cliped for a study area rename it to valid study area name
            old_name=sub_areas[0]
            new_name="%s/%s-%s"%(cwd,study_area,suffix)
            os.rename(old_name,new_name)
            main_log.append("only one extract for study area %s renamed %s to %s"%(study_area,old_name,new_name))
        else:
        # pull out the generated sample tifs <prov>_sample_<original-file-name>.tif
        # open each dataset and pass open dataset handle into dict array
        # test data types, resolutions and linear units
            dtypes=[]
            unique_dtypes=[]
            resolutions=[]
            unique_resolutions=[]
            linear_units=[]
            unique_lienar_units=[]
            for sub_area in sub_areas:    
                dataset=rasterio.open(sub_area,'r',GEOREF_SOURCES='INTERNAL')
                # merge needs to be on same datatypes, test datatypes for each clip
                test_dtype=dataset.dtypes[0]
                dtypes.append(test_dtype)
                main_log.append("Merge will fail if datatype are different - datatype for {}: {}".format(sub_area,test_dtype))
                datasets.append(dataset)
            unique_dtypes=list(set(dtypes))
            if len(unique_dtypes)>1:
                main_log.append("the {} study area cogs have more than one datatype, recasting to goal dtype ".format(study_area,goal_dtype))
                for dataset in datasets:
                    dataset.close()
                ## recast and merge cogs to specific datatype use datatype var to define set datatype
                # recast
                main_log.append("recasting study area {}".format(study_area))
                recast_log=recastData(study_area,goal_dtype,cwd)
                main_log.append("Recast Log:")
                main_log=main_log+recast_log
                main_log.append("completed recasting for study area {} {}".format(study_area,(str(datetime.now()))))
                # call merge data which calls merge files
                merge_log=mergeData(study_area,cwd,goal_csize,resample,goal_precision)
                main_log.append("Merge Log from mergeData/mergeFiles(more than one unique dtype):")
                main_log=main_log+merge_log
                main_log.append("completed merging for study area {} {}".format(study_area,(str(datetime.now()))))
            else:
                # grab out a few things from last open dataset
                crs=dataset.crs
                dtype=dataset.dtypes[0]
                nodata=dataset.nodata
                # call merge files directly
                sa_merge_file=mergeFiles(datasets,cwd,study_area,suffix,crs,nodata,goal_csize,resample,goal_precision)
                main_log.append("Merge Log from mergeFiles(single unique dtype):")
                main_log.append("merging for study area {} written to {}".format(study_area, sa_merge_file, goal_csize,goal_csize))    
        main_log.append("merging extracts finished %s"%(str(datetime.now())))
        main_log.append("cleaning up, deleting the sample files")
        sample_files=[]
        sample_str=os.path.join(cwd,"*_sample-*.tif")
        sample_files=glob.glob(sample_str)
        main_log.append("assessing keeptemp {}".format(keeptemp))
        if keeptemp:
            main_log.append("keeping temp tifs {}".format(sample_files))
        else:
            for sample_file in sample_files:
                os.remove(sample_file)
                main_log.append("removed sample file {}".format(sample_file))
                
            other_temps = ['request_dsm_intersection.json',
                           'request_dtm_intersection.json',
                           'original_request3979.json',
                           'dtm_dsm_difference.json',
                           'dtm_dsm_intersection.json',
                           'DescribeCoverage_dsm.json',
                           'DescribeCoverage_dsm.xml',
                           'DescribeCoverage_dtm.json',
                           'DescribeCoverage_dtm.xml']
            for other_temp in other_temps:
                temp_file = os.path.join(cwd,other_temp)
                if os.path.isfile(temp_file):
                    try:
                        os.remove(temp_file)
                        main_log.append("deleting temp file: {}".format(temp_file))
                    except Exception as e:
                        main_log.append("cannot remove temp file: {} exception: ".format(temp_file,str(e)))
                else:
                    main_log.append("temp file {} is not a file".format(temp_file))

    except Exception as e:
        error_log.append("start {}".format(datetime.now()))
        error_log.append('Exception info: %s' %(str(e)))
        etype, value, traceback = sys.exc_info()
        error_log.append('etype: %s'%(etype))
        error_log.append('value: %s'%(value))
        error_log.append('frame: %s'%(traceback.tb_frame))
        error_log.append('line number: %s'%(traceback.tb_lineno))
        error_log.append('last instruction: %s'%(traceback.tb_lasti))
        internal_log.append(appendListToFile(error_log,f_error))
        print(internal_log)
    #write out logs
    
    status_str="finished {}".format(datetime.now())
    print(status_str)
    main_log.append(status_str)
    internal_log.append(appendListToFile(main_log,f_main))
    internal_log.append(appendListToFile(stac_log,f_main))
    internal_log.appendListToFile(internal_log,f_main)
    print(internal_log)

##### DEFS

def appendListToFile(lines,fname):
    try:
        f=open(fname,'a')
        for line in lines:
            f.write("{}\n".format(line))
        f.close()
        r="wrote {} lines to {}".format(len(lines),fname)
    except Exception as e:
        r="Failed to write to {}.  Error: {}".format(fname,e)
    return r

def checkOutpath(outpath):
    if not os.path.exists(outpath):
        os.makedirs(outpath)
    return outpath

def deleteSampleAreaTifs(cwd,sample_id,f_main,f_error):
    cwd=checkOutpath(cwd)
    main_log=[]
    error_log=[]
    internal_log=[]
    try:
        search_str=os.path.join(cwd,"*{}*.tif".format(sample_id))
        main_log.append("deleting all {}".format(search_str))
        internal_log.append(appendListToFile(main_log,f_main))
        tifs=glob.glob(search_str)
        for tif in tifs:
            os.remove(tif)
    except Exception as e:
        error_log.append("start {}".format(datetime.now()))
        error_log.append("something went wrong with deleting tifs")
        error_log.append('Exception info: %s\n' %(str(e)))
        internal_log.append(appendListToFile(error_log,f_error))    
    return internal_log

def getBoundsFromFeatureCollection(fname):
    # takes a geojson feature collection file name
    # dissolves all the features together
    # return bounds and crs
    gdf=gpd.GeoDataFrame.from_file(fname)
    p=gdf.dissolve()
    return p.geometry[0].bounds,gdf.crs

def getBboxTupleFromBoundsTuple(bounds):
    # assuming bounds is a tuple
    # returns bbox tuple
    minx = bounds[0]
    miny = bounds[1]
    maxx = bounds[2]
    maxy = bounds[3]
    return ((minx,miny),(minx,maxy),(maxx,maxy),(maxx,miny))

def getCells(a,cellsize):
    numa,rema=divmod(a,cellsize)
    if rema!=0:
        cells=(numa+cellsize)
    else:
        cells=numa
    return cells

def getDictFromPoly(bbox):
    # converts shapely polygon bbox to python dict of geojson polygon defintion
    g = mapping(bbox)
    return g

def getEvenCellSizeLength(a,cellsize):
    cells = getCells(a,cellsize)
    #print("num of cells: {}".format(cells))
    return cells*cellsize


def getExtractFromStac(collection,asset_type,cwd,study_area,g,crs,f_main,f_error):
    cwd=checkOutpath(cwd)
    main_log=[]
    error_log=[]
    internal_log=[]
    file_names = []
    # pass in intersect geometry in EPSG:4326
    g4326=transform_geom(crs,'EPSG:4326',g)
    # set up for passing intersects to Franklin API via HTTP POST
    # pass in collection and intersect geometry as dict
    payload={"intersects":g4326,"collections":collection.split(',')}
    internal_log.append(f'payload: {payload}')# POST with polygon intersects
    try:
        # Using HTTP POST method
        franklin_api="https://datacube.services.geo.ca/api/search"
        r=requests.post(franklin_api,json=payload)
        results=json.loads(r.text)
        internal_log.append(f'results: {results}')
        urls=[]
        for result in results['features']:
            # for each defined cog, pass url to url 
            url=result['assets'][asset_type]['href']
            internal_log.append(f'url: {url}')
            # write out the sample
            try:
                file_name=makeImageFilesFromCog(url,cwd,study_area,g,crs,f_main,f_error)
                file_names.append(file_name)
                main_log.append(f'created file from STAC/COG {file_name}'
                                ' for study area {study_area}')
            except Exception as e:
                main_log.append(f"cant create file from {url}")
                error_log.append(f'makeImageFiles Error {e}')
                internal_log.append(appendListToFile(error_log,f_error))
        main_log.append("created files from STAC/COG for study area %s"%(study_area))
        internal_log.append(appendListToFile(main_log,f_main))
    except Exception as e:
        error_log.append("start {}".format(datetime.now()))
        error_log.append('Exception info for file {}: {}'.format(franklin_api,str(e)))
        etype, value, traceback = sys.exc_info()
        error_log.append('%s'%(etype))
        error_log.append('%s'%(value))
        error_log.append("frame: {}".format(traceback.tb_frame))
        error_log.append('line number: %s'%(traceback.tb_lineno))
        error_log.append('last instruction: %s'%(traceback.tb_lasti))
        internal_log.append(appendListToFile(error_log,f_error))
        #print(internal_log)   
    return file_names,internal_log

def getExtractFromWcs(collection,asset_type,cwd,study_area,g,crs,cellsize='30',
                      protocol='http',lid1='dtm',lid2='dsm',level='stage',srv_id='elevation',f_main='extract_main.log',
                      f_error='extract_error.log'):
    cwd=checkOutpath(cwd)
    crs_wcs='EPSG:3979'
    internal_log = []
    # get DTM and DSM bboxes
    if crs_wcs in crs:
        g3979=g
    else:
        g3979=getTransformFromDictToDict(g,crs,crs_wcs)
    f_lid1 = makeWcsBboxFile(level=level,lid=lid1,crs=crs_wcs,outpath=cwd)
    f_lid2 = makeWcsBboxFile(level=level,lid=lid2,crs=crs_wcs,outpath=cwd)
    # define areas that are dtm + dsm (use dsm) and areas where there is no dtm (use dsm)
    inter,diff = getGeoJsonBboxDifferences(f_lid1,f_lid2,cwd)
    f_lid1_zone='{}_{}_intersection.json'.format(lid1,lid2) # intersection is area want to request from dtm (lid)
    f_lid2_zone='{}_{}_difference.json'.format(lid1,lid2) # difference is area want to request from dsm (lid2)
    f_original='original_request3979.json'
    f_lid1_zone=makeVectorFile(inter,crs_wcs,cwd,f_lid1_zone)
    f_lid2_zone=makeVectorFile(diff,crs_wcs,cwd,f_lid2_zone)
    f_original=makeVectorFile(g3979,crs_wcs,cwd,f_original)
    # intersect request area with dtm zone and dtm zone to get the values to pass to wcs getCoverage request
    request_lid1,diff_lid1=getGeoJsonBboxDifferences(f_original,f_lid1_zone,cwd)
    request_lid2,diff_lid2=getGeoJsonBboxDifferences(f_original,f_lid2_zone,cwd)
    f_request_lid1='request_{}_intersection.json'.format(lid1)
    f_request_lid2='request_{}_intersection.json'.format(lid2)
    f_request_lid1=makeVectorFile(request_lid1,crs_wcs,cwd,f_request_lid1)
    f_request_lid2=makeVectorFile(request_lid2,crs_wcs,cwd,f_request_lid2)
    
    img_names=[]
    
    # see if dtm_request_area is of any size, then submit
    if getVectorFileArea(f_request_lid1) > 0:
        suffix='wcs-{}'.format(lid1)
        #convert python dict to shapely geom
        bbox_lid1=shape(request_lid1)
        lid1_attempt,lid1_img=getWcsGetCoverageAttempt(bbox_lid1,crs_wcs,
                                                       cellsize,protocol,lid1,
                                                       level,srv_id,cwd,
                                                       study_area,suffix,
                                                       f_main)
        internal_log.append(lid1_attempt)
        
        if '200' in lid1_attempt:
            img_names.append(lid1_img)
            #verify if the dtm image has data, if not then submit a dsm request
            if getImageHasData(lid1_img):
                internal_log.append("{} data available within dtm bbox".format(lid1))
            else:
                if getVectorFileArea(f_request_lid2) > 0:
                    # assuming that if there is no lid1 (dtm) data there will be 
                    # lid2 (dsm) data.  This is not the case in some areas with holes
                    internal_log.append("No {} data available within {} bbox, requesting {} instead".format(lid1,lid1,lid2))
                    suffix='wcs-{}for{}'.format(lid2,lid1)
                    (lid2for1_attempt,
                     lid2for1_img) = getWcsGetCoverageAttempt(bbox_lid1,
                                                              crs_wcs,
                                                              cellsize,
                                                              protocol,
                                                              lid2,
                                                              level,
                                                              srv_id,
                                                              cwd,
                                                              study_area,
                                                              suffix,
                                                              f_main)
                    if '200' in lid2for1_attempt:
                        img_names.append(lid2for1_img)
                    else:
                        internal_log.append("failed to create {} wcs image {}".format(suffix,lid2for1_attempt))
        else:
            internal_log.append("wcs request failed: {} ".format(lid1_attempt))
    else:
        internal_log.append("no area for {}, no wcs request attempted".format(f_request_lid1))
        
    # see if dsm_request_area is of any size, then submit
    if getVectorFileArea(f_request_lid2) > 0:
        # make a wcs call for HRDSM
        internal_log.append("part of request area is in wcs {} zone".format(lid2))
        suffix='wcs-{}'.format(lid2)
        bbox_lid2=shape(request_lid2)
        lid2_attempt,lid2_img=getWcsGetCoverageAttempt(bbox_lid2,
                                                       crs_wcs,
                                                       cellsize,protocol,lid2,
                                                       level,srv_id,
                                                       cwd,study_area,
                                                       suffix,
                                                       f_main)
        if '200' in lid2_attempt:
            img_names.append(lid2_img)
        else:
            internal_log.append("failed to create {} wcs image {}".format(suffix,lid2_attempt))
    else:
        internal_log.append("no area for {}, no wcs request attempted".format(f_request_lid2))
    
    appendListToFile(internal_log,f_main)
    return img_names,internal_log

def getFileParts(fn):
    # splits full file name into directories, filename, .ext
    head,tail=os.path.split(fn)
    root,ext=os.path.splitext(tail)
    return head,root,ext

def getGeoJsonBboxDifferences(f1='DescribeCoverage_dtm.json',f2='DescribeCoverage_dsm.json',cwd='./'):
    # return as dict geojson definitions
    cwd=checkOutpath(cwd)
    if cwd in f1:
        f1=f1
    else:
        f1=os.path.join(cwd,f1)
    if cwd in f2:
        f2=f2
    else:
        f2=os.path.join(cwd,f2)
    df1=gpd.GeoDataFrame.from_file(f1)
    df2=gpd.GeoDataFrame.from_file(f2)
    df_diff = df2.difference(df1)
    df_inter = df2.intersection(df1)
    return mapping(df_inter.geometry[0]),mapping(df_diff.geometry[0])

def getImageHasData(fname):
    has_data = False
    # If the number of nodata cells matches the full image size
    #  the image has no data
    # open image
    img=rasterio.open(fname)
    # read first band of image into numpy array
    arr=img.read(1)
    # calculate the number of pixels
    no_data_count=numpy.count_nonzero(arr==img.nodata)
    if no_data_count==arr.size:
        #image contains no data
        has_data=False
    else:
        #image contains data
        has_data=True
    del arr
    img.close()
    del img
    return has_data

def getLength(mina,maxa):
    if mina * maxa > 0:
        if abs(maxa)<abs(mina):
            c= abs(mina) - abs(maxa)
        else:
            c = abs(maxa) - abs(mina)
    else:
        c = abs(mina) + abs(maxa)     
    return c

def getMax(mina,delta):
    a=abs(mina)
    d=abs(delta)
    if mina<0:
        if d<a:
            maxa=(a-d)*-1
        else:
            maxa=d-a
    else:
        maxa=mina+delta
    #print("mina {}, a {}, delta {}, maxa {}".format(mina,a,delta,maxa))
    return maxa

def getPolyFromTbox(tbox='-269985.0,90015.0,-265875.0,95895.0'):
    #tbox='-269985.0,90015.0,-265875.0,95895.0'
    #crs='EPSG:3979'
    # convert bounding box strings to dict of floats
    b=[]
    for t in tbox.split(','):
        b.append(float(t))
    #create shapely polygon bbox
    bbox=box(*b)
    return bbox

def getResampleEnum(r):
    if 'average' in r:
        resample=rasterio.enums.Resampling.average
    elif 'bilinear' in r:
        resample=rasterio.enums.Resampling.bilinear
    elif 'cubic_spline' in r:
        resample=rasterio.enums.Resampling.cubic_spline
    elif 'cubic' in r:
        resample=rasterio.enums.Resampling.cubic
    elif 'gauss' in r:
        resample=rasterio.enums.Resampling.gauss
    elif 'lanczos' in r:
        resample=rasterio.enums.Resampling.lanczos
    elif 'max' in r:
        resample=rasterio.enums.Resampling.max
    elif 'med' in r:
        resample=rasterio.enums.Resampling.med         
    elif 'min' in r:
        resample=rasterio.enums.Resampling.min
    elif 'mode' in r:
        resample=rasterio.enums.Resampling.mode
    elif 'nearest' in r:
        resample=rasterio.enums.Resampling.nearest
    elif 'q1' in r:
        resample=rasterio.enums.Resampling.q1
    elif 'q3' in r:
        resample=rasterio.enums.Resampling.q3
    elif 'rms' in r:
        resample=rasterio.enums.Resampling.rms
    elif 'sum' in r:
        resample=rasterio.enums.Resampling.sum       
    else :
        resample=rasterio.enums.Resampling.average
    return resample

def getResolution(datasets,goal_csize):
    # if a resolution / cell_size argument is explicitly defined
    # merge needs to be passed in a cellsize in same linear units of images crs,
    # possible linear units values include “metre” and “US survey foot”
    # create a resolution tuple for merge
    # test using first dataset in list
    conversion=3.2808333333 
    dataset=datasets[0]
    goal_runits='metre'        
    if goal_csize>0:
        if dataset.crs.linear_units!=goal_runits:
            #assuming US survey foot"
            goal_csize=round(goal_csize*conversion)
        goal_res=(goal_csize,goal_csize)
    else:
        goal_res=dataset.res
    return goal_res

def getRootDomain(level='stage'):
    if not level in ['beta','dev','stage','prod']:
        level = 'stage'
        
    if 'beta' in level:
        rd = 'beta.datacube-stage.services.geo.ca/ows/'
    else:
        if 'prod' in level:
            rd='datacube.services.geo.ca/ows'
        else:
            rd = 'datacube-{}.services.geo.ca/ows'.format(level)
    return rd

def getSysPath():
    return sys.path

def getTboxFromBounds(bounds):
    #takes in poly bounds and returns text box
    return"{},{},{},{}".format(bounds[0],bounds[1],bounds[2],bounds[3])

def getTransformFromDictToDict(bbox_dict,in_crs,out_crs):
    # reproject geojson dict to geojson_dict
    g = transform_geom(in_crs,out_crs,bbox_dict)
    return g

def getTransformFromDictToPoly(bbox_dict,in_crs,out_crs):
    # reproject geojson dict to shapely polygon
    g = transform_geom(in_crs,out_crs,bbox_dict)
    return shape(g)
        
def getTransformFromPolyToDict(bbox,in_crs,out_crs):
    # reproject shapely polygon to geojson dict
    g = transform_geom(in_crs,out_crs,mapping(bbox))
    return g

def getTransformFromPolyToPoly(bbox,in_crs,out_crs):
    # reproject shapely polygon to shapely polygon
    g = transform_geom(in_crs,out_crs,mapping(bbox))
    return shape(g)

def getVectorFileArea(fname):
    gs=gpd.GeoSeries.from_file(fname)
    return gs.area[0]

def getWcsGetCoverageAttempt(geojson_as_dict,crs,cellsize,protocol,lid,level,
                             srv_id,cwd='./',study_area='test',
                             suffix='wcs-dtm',f_main='main.log'):
    #convert python geojson dict to shapely geom
    cwd=checkOutpath(cwd)
    bbox=shape(geojson_as_dict)
    # get url for request and input bounds tuple for comparison to result
    u,i=getWcsRequestByCellSize(bbox,crs,cellsize,protocol,lid,level,srv_id,f_main)
    #print('{} calcd u {}'. format(suffix,u))
    # write image out to test.tif in 128 byte chunks if r.status_code=200
    img_name=os.path.join(cwd,"{}_sample-{}.tif".format(study_area,suffix))
    return writeOutResultStream(u,img_name,f_main),img_name

def getWcsRequestByCellSize(bbox,crs='EPSG:3979',cellsize=30,protocol='https',
                            lid='dtm',level='beta',srv_id='elevation',f_main='main.log'):
    # converts requests to EPSG:3979
    crs3979='EPSG:3979'
    # need to select an area evenly divdable by pixel size with bbox
    # equal to minx-(cellsize/2),minx-(cellsize/2),maxx-(cellsize/2),maxy-cellsize/2)
    #level='stage'
    rd=getRootDomain(level)
    srv_id='elevation'
    # convert bbox to 3979 for calculation
    if '3979' in crs:
        bbox3979=bbox
    else:
        bbox3979 = shape(transform_geom(crs,crs3979,mapping(bbox)))
    #print('submited bbox {}'.format(mapping(bbox)))
    #print('bbox3979 {}'.format(mapping(bbox3979)))
    minx,miny,maxx,maxy=bbox3979.bounds
    #print('original 3979 submited to wcs minx,miny,maxx,maxy {}, {}, {}, {}'.format(minx,miny,maxx,maxy))
    dx = getLength(minx,maxx)
    dy = getLength(miny,maxy)
    #print("dx: {}".format(dx))
    #print("dy: {}".format(dy))
    # find the delta x and y
    deltax = getEvenCellSizeLength(dx,cellsize)
    deltay = getEvenCellSizeLength(dy,cellsize)
    #print("deltax: {}".format(deltax))
    #print("deltay: {}".format(deltay))
    maxx = getMax(minx,deltax)
    maxy = getMax(miny,deltay)
    #print('calced 3979 submited to wcs bbox minx,miny,maxx,maxy {}, {}, {}, {}'.format(minx,miny,maxx,maxy))
          
    coords=box(minx,miny,maxx,maxy)
    # pass bbox and identifier into call
    root = "{}://{}/{}".format(protocol,rd,srv_id)
    params = "service=WCS&version=1.1.1&request=GetCoverage&format=image/geotiff"
    params += "&identifier={}".format(lid)
    params += "&BoundingBox={},{},{},{},urn:ogc:def:crs:EPSG::3979".format(minx,miny,maxx,maxy)
    #params+="&BoundingBox=-269985.0,90015.0,-180015.0,179985.0,urn:ogc:def:crs:EPSG::3979"
    params += "&GridBaseCRS=urn:ogc:def:crs:EPSG::3979&GridOffsets={:.1f},-{:.1f}".format(float(cellsize),float(cellsize))
    return "{}?{}".format(root,params),coords.bounds

def makeImageFilesFromCog(url,cwd,name,geom_d,crs,f_main,f_error):
    main_log = []
    error_log = []
    cwd=checkOutpath(cwd)
    # print(f'makeImageFilesFromCog cwd {cwd}')
    # write the sample out to a file 'sample_<filename>'
    file_name="%s/%s_sample-%s"%(cwd,name,url.split('/')[-1])
    main_log.append(f'makeImageFilesFromCog file_name {file_name}')
    #print(file_name)
    # open cog with all types of GeoTIFF georeference except that within the TIFF file’s keys and tags turned off
    cog=rasterio.open(url,GEOREF_SOURCES='INTERNAL')

    # input crs matches cog crs
    t = transform_geom(crs,cog.crs,geom_d)

    geom_cog = shapely.geometry.shape(t)

    main_log.append(f'makeImageFilesFromCog geom_cog : {geom_cog}')
    appendListToFile(main_log,f_main)
    # convert geom dict to a list and pass in to mask
    # want crop = True and all other params default values
    try:
        sample_cog,cog_transform = mask(dataset=cog,shapes=[geom_cog],crop=True)

        #calculate height and width index of shape from number of dimensions
        height=sample_cog.shape[sample_cog.ndim-2]
        width=sample_cog.shape[sample_cog.ndim-1]
        
        dst=rasterio.open(
            file_name,
            'w+',
            driver='GTiff',
            height=height,
            width=width,
            count=1,
            dtype=cog.dtypes[0],
            crs=cog.crs,
            transform=cog_transform,
            nodata=cog.nodata,
            GEOREF_SOURCES='INTERNAL',
            compress='LZW',
            tiled=True,
            blockxsize=256,
            blockysize=256
            )
        dst.write(sample_cog)
        dst.close()
        cog.close()
    except Exception as e:
        error_log.append(f'MakeImageFileFromCog Error with mask or writing file {e}')
        appendListToFile(error_log,f_error)
    return file_name

def makeImageFileFromWcs(img_name):
    # clean up wcs
    # convert to 32 byte with no data of -32767
    new_nodata=-32767
    new_dtype='float32'
    # open extract from wcs and pull out all required infoo
    old=rasterio.open(img_name)
    old_transform=old.transform
    height=old.height
    width=old.width
    crs=old.crs
    old_nodata=old.nodata
    arr=old.read(1)
    #print("pre reformat")
    #print(arr)
    old.close()
##    # delete extract
##    os.remove(img_name)
    new_img_name="{}.f32nd.tif".format(img_name)
    # recast data and replace nodata
    arr=numpy.round_(arr, decimals=0, out=arr)
    arr=arr.astype(new_dtype,order='K',casting='unsafe',subok=True,copy=False,)
    arr=numpy.where(arr==old_nodata,new_nodata,arr)
    #print("post reformat")
    #print(arr)
    # write out file with new pixel depth and no datavalues
    dst=rasterio.open(
        new_img_name,
        'w+',
        driver='GTiff',
        height=height,
        width=width,
        count=1,
        dtype=new_dtype,
        crs=crs,
        transform=old_transform,
        nodata=new_nodata,
        GEOREF_SOURCES='INTERNAL',
        compress='LZW',
        tiled=True,
        blockxsize=256,
        blockysize=256
        )
    dst.write(arr,1)
    dst.close()
    return

def makeVectorFile(dict_poly,crs,outpath,filename,driver='GeoJSON'):
# takes a polygon dict geojson defintion and converts it to a geojson vector definition file
    #poly={'type': 'Polygon', 'coordinates': (((-419184.0, 1231541.0), (-419184.0, 1345927.2), (-486516.2, 1345927.2), (-486516.2, 1231541.0), (-419184.0, 1231541.0)),)}
    #crs='EPSG:3979'
    # check outpath exists
    outpath=checkOutpath(outpath)
    gs=gpd.GeoSeries(shape(dict_poly),crs=crs)
    fname=os.path.join(outpath,filename)
    gs.to_file(os.path.join(outpath,filename),driver='GeoJSON')
    return fname

def makeWcsBboxFile(level='stage',lid="dtm",crs='EPSG:3979',v="1.1.0",outpath='./'):
    # Use return from wcs DescribeCoverage to create a geojson bbox
    #https://datacube-stage.services.geo.ca/ows/elevation?version=1.1.0&service=wcs&request=DescribeCoverage&identifiers=dtm
    # reformat crs : to match xml encoding to differ from namespace ':' -> '::'
    minx=0
    miny=0
    maxx=0
    maxy=0
    crs2=crs.replace(':','::')
    protocol = "https"
    service = "elevation"
    rd = getRootDomain(level)
    r = "{}://{}/{}".format(protocol,rd,service)
    #r="https://datacube-stage.services.geo.ca/ows/elevation"
    p = "service=wcs&request=DescribeCoverage&version={}&identifiers={}".format(v,lid)
    u = "{}?{}".format(r,p)
    r=requests.get(u)
    fn=os.path.join(outpath,'DescribeCoverage_{}.xml'.format(lid))
    f=open(fn,'w',encoding='UTF-8')
    f.write(r.text)
    f.close()
    tree=et.parse(fn)
    root = tree.getroot()
    # define namespaces as dict
    ns = {'ows': 'http://www.opengis.net/ows/1.1', 'wcs': 'http://www.opengis.net/wcs/1.1.1'}
    bbs=root.findall("wcs:CoverageDescription/wcs:Domain/wcs:SpatialDomain/ows:BoundingBox[@crs]",ns)
    for bb in bbs:
        if crs2 in bb.attrib['crs']:
            for gbb in bb:
                if 'UpperCorner' in gbb.tag:
                    maxx,maxy=gbb.text.split(' ')
                    
                if 'LowerCorner' in gbb.tag:
                    minx,miny=gbb.text.split(' ')
                #else:
                    #print("no vals")

        #split file name into dirs, name, .ext
        d,f,e=getFileParts(fn)
        gn='{}.json'.format(f)
        g=getDictFromPoly(getPolyFromTbox('{}, {}, {}, {}'.format(minx,miny,maxx,maxy)))
        gn_full=makeVectorFile(g,crs,outpath,gn)
    return gn_full

def mergeData(study_area,cwd,goal_csize,resample,goal_precision):
    cwd=checkOutpath(cwd)
    log=[]
    #merging
    sub_areas=sorted(glob.glob(os.path.join(cwd,"{}_sample-*.tif".format(study_area))),reverse=True)
    log_str="merging study area {} sub areas {}".format(study_area,sub_areas)
    #print(log_str)
    log.append(log_str)
    datasets=[]
    #suffix="study-area.tif"
    suffix = ".tif"
    if len(sub_areas)==1:
        old_name=sub_areas[0]
        new_name="%s-%s"%(study_area,suffix)
        os.rename(old_name,new_name)
        log.append("only one extract for study area {} renamed {} to {}".format(study_area,old_name,new_name))
    else:
        #could recheck again for single dtype
        dtypes=[]
        unique_dtypes=[]
        for sub_area in sub_areas:
            dataset=rasterio.open(sub_area,'r',GEOREF_SOURCES='INTERNAL')
            datasets.append(dataset)
        # grab out a few things from last open dataset
        crs=dataset.crs
        dtype=dataset.dtypes[0]
        nodata=dataset.nodata
        # call function
        sa_merge_file=mergeFiles(datasets,cwd,study_area,suffix,crs,nodata,goal_csize,resample,goal_precision)
        log.append(sa_merge_file)
        log.append("merging for study area {} written to {}".format(study_area, sa_merge_file))
    return log

def mergeFiles(datasets,cwd,study_area,suffix,crs,nodata,goal_csize,resample,goal_precision):
    cwd=checkOutpath(cwd)
    log=[]
    res=getResolution(datasets,goal_csize)
    print(f'resolution {res}')
    precision=4
    #merge the open datasets to a numpy array
    merge_arr,merge_affine=merge.merge(datasets,res=res,resampling=resample,precision=goal_precision)
    print(f'merge array shape : {merge_arr.shape}')
    print(f'merge affine : {merge_affine}')
    for dataset in datasets:
        dataset.close()
    #sa_merge_file=os.path.join(cwd,"{}_{}_p{}-{}".format(study_area,resample.name,res[0],suffix))
    #Heather wants GRIDID_DTM_O_30
    sa_merge_file = os.path.join(cwd,"{}{}".format(study_area,suffix))
    log.append(sa_merge_file)
    #write array to cog
    m=rasterio.open(
        sa_merge_file,'w',
        height=merge_arr.shape[1],
        width=merge_arr.shape[2],
        transform=merge_affine,
        dtype=merge_arr.dtype,
        crs=crs,
        count=1,
        driver='GTiff',
        compress='LZW',
        tiled=True,
        blockxsize=256,
        blockysize=256,
        nodata=nodata,
        GEOREF_SOURCES='INTERNAL'
        )
    m.write(merge_arr)
      ## cant add description header with all of the source files - not working
      ## does not work m.update_tags(a= ','.join(datasets))
      ## does not work m.set_band_description(1, ','.join(datasets))
    m.close()
    return log
    
def recastData(study_area,goal_dtype,cwd):
    #initialise
##    study_area='ON'
##    goal_dtype=16
    cwd=checkOutpath(cwd)
    log=[]
    files=[]
    sub_areas=[]
    if goal_dtype == 16:
        target_dtype=numpy.int16
        target_str='int16'
    elif goal_dtype == 8:
        target_dtype=numpy.int8
        target_str='int8'
    elif goal_dtype == 32:
        target_dtype=numpy.float32
        target_str='float32'
    else:
        target_dtype=numpy.int16
        target_str='int8'
    # get the files to be tested and recast if necessary
    files=glob.glob("%s/%s_sample-*.tif"%(cwd,study_area))
    for file in files:
        if 'study_area' in file:
            log.append("study area already has a merged file %s ... exiting"%(file))
            exit
        else:
            sub_areas.append(file)
    log.append("sub areas include")
    log.append("{}".format(sub_areas))
    # test the merge data is all type int16
    for sub_area in sub_areas:
        dataset=rasterio.open(sub_area,GEOREF_SOURCES='INTERNAL')
        test_dtype=dataset.dtypes[0]
        # grab out a few things from last open dataset
        crs=dataset.crs
        log.append("crs: %s"%(crs))
        dtype=dataset.dtypes[0]
        log.append("dtype: %s"%(dtype))
        # wcs nan nodata temp patch
        if dataset.nodata:
            nodata=dataset.nodata
        else:
            nodata=0
        log.append("shape: %s"%(str(dataset.shape)))
        log.append("nodata: %s"%(nodata))
        log.append("datatype for %s: %s"%(sub_area,test_dtype))
        if str(goal_dtype) in test_dtype:
            log.append("no recast for {} it is already in the target datatype ... closing".format(sub_area))
            dataset.close()
            # datasets.append(dataset)
        else:
            # split file and path
            file_parts=os.path.split(sub_area)
            in_cwd=file_parts[0]
            in_name=file_parts[1]
            #recast to target type
            recast_ar=dataset.read(1)
            dataset.close()
            log.append("before rounding from %s to %s: min: %s,max: %s"%(test_dtype,target_str,str(numpy.amin(recast_ar)),str(numpy.amax(recast_ar))))
            recast_ar=numpy.round_(recast_ar, decimals=0, out=recast_ar)
            log.append("after rounding and before recast from %s to %s: min: %s,max: %s"%(test_dtype,target_str,str(numpy.amin(recast_ar)),str(numpy.amax(recast_ar))))
            recast_ar=recast_ar.astype(target_dtype,order='K',casting='unsafe',subok=True,copy=False,)
            log.append("after recast from %s to %s: min: %s,max: %s"%(test_dtype,target_str,str(numpy.amin(recast_ar)),str(numpy.amax(recast_ar))))

            file_name=("%s/%s_%s"%(in_cwd,target_str,in_name))
            log.append("transform")
            log.append("{}".format(dataset.transform))
            #write the file out
            dst=rasterio.open(
                file_name,
                'w',
                driver='GTiff',
                height=dataset.shape[0],
                width=dataset.shape[1],
                count=1,
                dtype=target_dtype,
                crs=dataset.crs,
                transform=dataset.transform,
                nodata=nodata, 
                GEOREF_SOURCES='INTERNAL',
                compress='LZW',
                tiled=True,
                blockxsize=256,
                blockysize=256
                )
            dst.write(recast_ar, 1)
            dst.close()
            dataset.close()
            #rename tifs
            file_to_delete=os.path.join(in_cwd,"wrong_dtype_{}_{}".format(test_dtype,in_name))
            os.rename(sub_area,file_to_delete)
            os.rename(file_name,sub_area)
            # delete old file
            os.remove(file_to_delete)
    log.append("created files for study area {}".format(study_area))
    return log
    
def useStudyAreaGeojson(geojson_file,field,extract_id):
    to_crs='EPSG:4326'
    # check for geojson file
    if not os.path.isfile(geojson_file):
        sys.exit("No json file, if a service it should be a 400 bad request")
    #create lat lon geodataframe with all of the study areas
    sas=gpd.read_file(geojson_file)
    ll_sas=sas.to_crs(to_crs)
    # grab out study area name
    name=ll_sas[ll_sas[field]==extract_id][field].values[0]
    study_area=name
    # grab out study area geometry as geopandas geoseries
    geometry=ll_sas[ll_sas[field]==extract_id]['geometry']
    # transform geopanda geoseries to python dict
    g=json.loads(geometry.to_json())["features"][0]["geometry"]
    return study_area,g,to_crs

def writeOutResultStream(u,img_name,f_main='main.log'):
    """ sends get request to wcs and writes out result to image"""
    main_log = []
    main_log.append(f'getting wcs result stream from  get request {u}')
    main_log.append(f'writing result to {img_name}')
    appendListToFile(main_log,f_main)
    r=requests.get(u)
    sc=r.status_code
    reason=r.reason
    # write image out to test.tif in 128 byte chunks if r.status_code=200
    if sc==200 :
        with open(img_name,'wb') as img:
             for chunk in r.iter_content(chunk_size=128):
                 img.write(chunk)
        img.close()
    r.close()
    return "{} request sc:{} reason:{}".format(img_name,sc,reason)
if __name__ == '__main__':
    main(sys.argv[1:])
